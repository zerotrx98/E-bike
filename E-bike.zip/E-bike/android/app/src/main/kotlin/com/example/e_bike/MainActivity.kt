package com.example.e_bike

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
