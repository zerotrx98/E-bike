import 'package:cloud_firestore/cloud_firestore.dart';
import'package:flutter/material.dart';

class Servies extends StatelessWidget {
  final CollectionReference store =
  FirebaseFirestore.instance.collection('services');

  TextEditingController dateController = TextEditingController();
  TextEditingController handlingPersonController = TextEditingController();
  TextEditingController deliveryDateController = TextEditingController();
  TextEditingController timeController = TextEditingController();
  TextEditingController kmController = TextEditingController();
  TextEditingController complaint01Controller = TextEditingController();
  TextEditingController complaint02Controller = TextEditingController();
  TextEditingController complaint03Controller = TextEditingController();
  TextEditingController complaint04Controller = TextEditingController();
  TextEditingController complaint05Controller = TextEditingController();
  TextEditingController spareParts01Controller = TextEditingController();
  TextEditingController spareParts02Controller = TextEditingController();
  TextEditingController spareParts03Controller = TextEditingController();
  TextEditingController spareParts04Controller = TextEditingController();
  TextEditingController spareParts05Controller = TextEditingController();
  TextEditingController billamountController = TextEditingController();

  @override
  Widget build(BuildContext context) {

    final args = ModalRoute.of(context)!.settings.arguments as Map;
    dateController.text = args['date'] ?? '';
    handlingPersonController.text = args['handlingPerson'] ?? '';
    deliveryDateController.text = args['deliveryDate'] ?? '';
    timeController.text = args['time'] ?? '';
    kmController.text = args['km'] ?? '';
    complaint01Controller.text = args['complaint01'] ?? '';
    complaint02Controller.text = args['complaint02'] ?? '';
    complaint03Controller.text = args['complaint03'] ?? '';
    complaint04Controller.text = args['complaint04'] ?? '';
    complaint05Controller.text = args['complaint05'] ?? '';
    spareParts01Controller.text = args['spareParts01'] ?? '';
    spareParts02Controller.text = args['spareParts02'] ?? '';
    spareParts03Controller.text = args['spareParts03'] ?? '';
    spareParts04Controller.text = args['spareParts04'] ?? '';
    spareParts05Controller.text = args['spareParts05'] ?? '' ;
    spareParts05Controller.text = args['billAmount'] ?? '' ;
    final docId = args['id'];

    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        actions: <Widget>[
          IconButton(
            icon: const Icon(Icons.search_off),
            tooltip: 'search',
            onPressed: () {
              //   Navigator.push(context, MaterialPageRoute(builder: (_)=> Billing1()));
              //
            },
          ),
        ],
        title: const Text('Services  ',
          style: TextStyle( color:Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.w600
          ),),
        backgroundColor: Colors.green[900],
        elevation: 0,
      ),
      body:
      Column(
        children: [
          Card(
            child: Container(
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey,
                      blurRadius: 10,
                      spreadRadius: 3,
                    )
                  ]
              ),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      children: [
                        Container(
                          child: Row(
                            children: <Widget>[
                              Text("Date:" ,style: TextStyle(fontSize: 20,
                                  fontWeight: FontWeight.w600,color: Colors.black
                              )),
                              Padding(
                                padding:const EdgeInsets.only(left: 95.0,right: 0,bottom: 0,top: 0),
                                child: Text(
                                    args['date'],
                                    style: TextStyle(fontSize: 18,
                                        fontWeight: FontWeight.w600,color: Colors.black54
                                    )
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Container(
                          child: Row(
                            children: <Widget>[
                              Text("HandlingPerson:" ,style: TextStyle(fontSize: 20,
                                  fontWeight: FontWeight.w600,color: Colors.black
                              )),
                              Padding(
                                padding:const EdgeInsets.only(left: 65.0,right: 0,bottom: 0,top: 0),
                                child: Text(
                                    args['handlingperson'],
                                    style: TextStyle(fontSize: 18,
                                        fontWeight: FontWeight.w600,color: Colors.black54
                                    )
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Container(
                          child: Row(
                            children: <Widget>[
                              Text("DeliveryDate:" ,style: TextStyle(fontSize: 20,
                                  fontWeight: FontWeight.w600,color: Colors.black
                              )),
                              Padding(
                                padding:const EdgeInsets.only(left: 85.0,right: 0,bottom: 0,top: 0),
                                child: Text(
                                    args['deliveryDate'],
                                    style: TextStyle(fontSize: 18,
                                        fontWeight: FontWeight.w600,color: Colors.black54
                                    )
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Container(
                          child: Row(
                            children: <Widget>[
                              Text("Time:" ,style: TextStyle(fontSize: 20,
                                  fontWeight: FontWeight.w600,color: Colors.black
                              )),
                              Padding(
                                padding:const EdgeInsets.only(left: 104.0,right: 0,bottom: 0,top: 0),
                                child: Text(
                                    args['time'],
                                    style: TextStyle(fontSize: 18,
                                        fontWeight: FontWeight.w600,color: Colors.black54
                                    )
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Container(
                          child: Row(
                            children: <Widget>[
                              Text("Km:" ,style: TextStyle(fontSize: 20,
                                  fontWeight: FontWeight.w600,color: Colors.black
                              )),
                              Padding(
                                padding:const EdgeInsets.only(left: 104.0,right: 0,bottom: 0,top: 0),
                                child: Text(
                                    args['km'],
                                    style: TextStyle(fontSize: 18,
                                        fontWeight: FontWeight.w600,color: Colors.black54
                                    )
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Container(
                          child: Row(
                            children: <Widget>[
                              Text("Complaint01:" ,style: TextStyle(fontSize: 20,
                                  fontWeight: FontWeight.w600,color: Colors.black
                              )),
                              Padding(
                                padding:const EdgeInsets.only(left: 104.0,right: 0,bottom: 0,top: 0),
                                child: Text(
                                    args['complaint01'],
                                    style: TextStyle(fontSize: 18,
                                        fontWeight: FontWeight.w600,color: Colors.black54
                                    )
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Container(
                          child: Row(
                            children: <Widget>[
                              Text("Complaint02:" ,style: TextStyle(fontSize: 20,
                                  fontWeight: FontWeight.w600,color: Colors.black
                              )),
                              Padding(
                                padding:const EdgeInsets.only(left: 20.0,right: 0,bottom: 0,top: 0),
                                child: Text(
                                    args['complaint02'],
                                    style: TextStyle(fontSize: 18,
                                        fontWeight: FontWeight.w600,color: Colors.black54
                                    )
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Container(
                          child: Row(
                            children: <Widget>[
                              Text("Complaint03:" ,style: TextStyle(fontSize: 20,
                                  fontWeight: FontWeight.w600,color: Colors.black
                              )),
                              Padding(
                                padding:const EdgeInsets.only(left: 80.0,right: 0,bottom: 0,top: 0),
                                child: Text(
                                    args['complaint03'],
                                    style: TextStyle(fontSize: 18,
                                        fontWeight: FontWeight.w600,color: Colors.black54
                                    )
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Container(
                          child: Row(
                            children: <Widget>[
                              Text("Complaint04:" ,style: TextStyle(fontSize: 20,
                                  fontWeight: FontWeight.w600,color: Colors.black
                              )),
                              Padding(
                                padding:const EdgeInsets.only(left: 45.0,right: 0,bottom: 0,top: 0),
                                child: Text(
                                    args['complaint04'],
                                    style: TextStyle(fontSize: 18,
                                        fontWeight: FontWeight.w600,color: Colors.black54
                                    )
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Container(
                          child: Row(
                            children: <Widget>[
                              Text("Complaint05:" ,style: TextStyle(fontSize: 20,
                                  fontWeight: FontWeight.w600,color: Colors.black
                              )),
                              Padding(
                                padding:const EdgeInsets.only(left: 70.0,right: 0,bottom: 0,top: 0),
                                child: Text(
                                    args['complaint05'],
                                    style: TextStyle(fontSize: 18,
                                        fontWeight: FontWeight.w600,color: Colors.black54
                                    )
                                ),
                              ),
                            ],
                          ),
                        ),  SizedBox(
                          height: 10,
                        ),
                        Container(
                          child: Row(
                            children: <Widget>[
                              Text("SpareParts01:" ,style: TextStyle(fontSize: 20,
                                  fontWeight: FontWeight.w600,color: Colors.black
                              )),
                              Padding(
                                padding:const EdgeInsets.only(left: 104.0,right: 0,bottom: 0,top: 0),
                                child: Text(
                                    args['spareParts01'],
                                    style: TextStyle(fontSize: 18,
                                        fontWeight: FontWeight.w600,color: Colors.black54
                                    )
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Container(
                          child: Row(
                            children: <Widget>[
                              Text("SpareParts02:" ,style: TextStyle(fontSize: 20,
                                  fontWeight: FontWeight.w600,color: Colors.black
                              )),
                              Padding(
                                padding:const EdgeInsets.only(left: 20.0,right: 0,bottom: 0,top: 0),
                                child: Text(
                                    args['spareParts02'],
                                    style: TextStyle(fontSize: 18,
                                        fontWeight: FontWeight.w600,color: Colors.black54
                                    )
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Container(
                          child: Row(
                            children: <Widget>[
                              Text("SpareParts03:" ,style: TextStyle(fontSize: 20,
                                  fontWeight: FontWeight.w600,color: Colors.black
                              )),
                              Padding(
                                padding:const EdgeInsets.only(left: 80.0,right: 0,bottom: 0,top: 0),
                                child: Text(
                                    args['spareParts03'],
                                    style: TextStyle(fontSize: 18,
                                        fontWeight: FontWeight.w600,color: Colors.black54
                                    )
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Container(
                          child: Row(
                            children: <Widget>[
                              Text("SpareParts04:" ,style: TextStyle(fontSize: 20,
                                  fontWeight: FontWeight.w600,color: Colors.black
                              )),
                              Padding(
                                padding:const EdgeInsets.only(left: 45.0,right: 0,bottom: 0,top: 0),
                                child: Text(
                                    args['spareParts04'],
                                    style: TextStyle(fontSize: 18,
                                        fontWeight: FontWeight.w600,color: Colors.black54
                                    )
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Container(
                          child: Row(
                            children: <Widget>[
                              Text("SpareParts05:" ,style: TextStyle(fontSize: 20,
                                  fontWeight: FontWeight.w600,color: Colors.black
                              )),
                              Padding(
                                padding:const EdgeInsets.only(left: 70.0,right: 0,bottom: 0,top: 0),
                                child: Text(
                                    args['spareParts05'],
                                    style: TextStyle(fontSize: 18,
                                        fontWeight: FontWeight.w600,color: Colors.black54
                                    )
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Container(
                          child: Row(
                            children: <Widget>[
                              Text("BillAmount:" ,style: TextStyle(fontSize: 20,
                                  fontWeight: FontWeight.w600,color: Colors.black
                              )),
                              Padding(
                                padding:const EdgeInsets.only(left: 65.0,right: 0,bottom: 0,top: 0),
                                child: Text(
                                    args['billAmount'],
                                    style: TextStyle(fontSize: 18,
                                        fontWeight: FontWeight.w600,color: Colors.black54
                                    )
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),

        ],
      ),
    );
  }
}
