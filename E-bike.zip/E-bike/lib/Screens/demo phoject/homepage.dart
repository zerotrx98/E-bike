import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../newCustomer.dart';
import 'NEW.dart';
class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}
class _HomeState extends State<Home> {

  final CollectionReference store =
  FirebaseFirestore.instance.collection('car');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green[900],
        actions: <Widget>[
          IconButton(
            icon: const Icon(Icons.local_print_shop_sharp),
            tooltip: 'billing',
            onPressed: () {
              //   Navigator.push(context, MaterialPageRoute(builder: (_)=> Billing1()));
              //
            },
          ),
          IconButton(
            icon: const Icon(Icons.local_grocery_store_outlined),
            tooltip: 'E-store',
            onPressed: () {
              // Navigator.push(context, MaterialPageRoute(builder: (_)=> Store1()));
              //
            },
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => New()),
          );
          //
        },
        backgroundColor: Colors.green[900],
        foregroundColor: Colors.black,
        child: Icon(Icons.add),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endContained,
      body: StreamBuilder(
        stream: store.orderBy('name').snapshots(),
        builder: (context, AsyncSnapshot snapshot) {
          if (snapshot.hasData) {
            return ListView.builder(
              itemCount: snapshot.data.docs.length,
              itemBuilder: (context, index) {
                final DocumentSnapshot dataStore = snapshot.data.docs[index];
                return InkWell(
                  onTap: () {
                    Navigator.pushNamed(
                      context,
                      '/exCustomer',
                      arguments: {
                        'name': dataStore['name'],
                        'phoneNo': dataStore['phoneNo'],
                        'vehicle': dataStore['vehicle'],
                        'place': dataStore['place'],
                        'registrationNo': dataStore['registrationNo'],
                        'motorNo': dataStore['motorNo'],
                        'ControllerNo': dataStore['ControllerNo'],
                        'chasesNo': dataStore['chasesNo'],
                        //service01
                        'date01': dataStore['date01'],
                        'handlingPerson01': dataStore['handlingPerson01'],
                        'deliveryDate01': dataStore['deliveryDate01'],
                        'time01': dataStore['time01'],
                        'km01':dataStore['km01'],
                        'complaint0101':dataStore['complaint0101'],
                        'complaint0102':dataStore['complaint0102'],
                        'complaint0103':dataStore['complaint0103'],
                        'complaint0104':dataStore['complaint0104'],
                        'complaint0105':dataStore['complaint0105'],
                        'sparePart0101':dataStore['sparePart0101'],
                        'sparePart0102':dataStore['sparePart0102'],
                        'sparePart0103':dataStore['sparePart0103'],
                        'sparePart0104':dataStore['sparePart0104'],
                        'sparePart0105':dataStore['sparePart0105'],
                        'billAmount01':dataStore['billAmount01'],
                        'id': dataStore.id,
                      },
                    );
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      children: [
                        Stack(
                          children: [
                            Container(
                              height: 60,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                                color: Colors.white,
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.grey,
                                    blurRadius: 10,
                                    spreadRadius: 3,
                                  ),
                                ],
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.only(
                                      left: 10.0,
                                      right: 10,
                                      bottom: 10,
                                      top: 10,
                                    ),
                                    child: Text(
                                      dataStore['date01'],
                                      style: TextStyle(fontSize: 20),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Positioned(
                              top: 4,
                              right: 0,
                              bottom: 0,
                              child: PopupMenuButton(
                                itemBuilder: (context) {
                                  return [
                                    PopupMenuItem<int>(
                                      value: 0,
                                      child: Text("Edit"),
                                    ),
                                  ];
                                },
                                onSelected: (value) {
                                  if (value == 0) {
                                    Navigator.pushNamed(
                                      context,
                                      '/updateCustomer',
                                      arguments: {
                                        'name': dataStore['name'],
                                        'phoneNo': dataStore['phoneNo'],
                                        'vehicle': dataStore['vehicle'],
                                        'place': dataStore['place'],
                                        'registrationNo': dataStore['registrationNo'],
                                        'motorNo': dataStore['motorNo'],
                                        'ControllerNo': dataStore['ControllerNo'],
                                        'chasesNo': dataStore['chasesNo'],
                                        'id': dataStore.id,
                                      },
                                    );
                                  }
                                },
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          } else if (snapshot.hasError) {
            return Text('Error: ${snapshot.error}');
          } else {
            return Container(
              height: MediaQuery.of(context).size.height,
              width: MediaQuery.of(context).size.width,
              color: Colors.white,
            );
          }
        },
      ),
    );
  }
}